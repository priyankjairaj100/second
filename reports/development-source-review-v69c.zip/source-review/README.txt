Source review component: adapted copies, not executed research bytes

This component contains534 source/protocol/wrapper files from the prepared chain.
It includes the two legacy helper/package files required by the static import review.
Thirty-four files have only declared account/repository/node/path identifiers replaced.
Every copy reverses to its committed original bytes using a separate provenance map.
All503 Python files parse with Python3.10 grammar; their ASTs differ only by those
string replacements. This does not establish numerical or operational equivalence.

Placeholders
/review/project is an illustrative checkout root, /review/runtime an interpreter
installation prefix, review_user an account, reviewcluster.* illustrative node names and
REVIEW_OWNER/REVIEW_REPOSITORY a repository placeholder. Historical institution
markers become reviewcluster_ or REVIEW_CLUSTER. They are not available
services. No source is licensed anew by this component; project release terms and
third-party notices are still being reviewed. No dependency/model/data/environment
binaries, real registrations, live ledgers or article token arrays are bundled.
The original source may contain tiny generated software-test fixtures.

Do not run historical empirical launchers or attempt to satisfy their original
hashes with these adapted bytes. Frozen source/runtime/input hashes and one-use
guards still describe the preserved original experiments. Empirical reproduction
requires a NEW prospectively admitted environment, paths, inputs, registration,
resource budget and one-use attempt. The active V67 experiment is unchanged.

Local fixture check
The included qualify_review_source.py checks22 V68 and92 V69 generated fixtures
from an extracted copy using CPython3.12.7 with NumPy2.3.5 in an existing environment. This is a local
fixture environment, not a production runtime lock. Invoke with
python -I -B qualify_review_source.py PATH_TO_THIS_DIRECTORY --report REPORT.json
--log TESTS.txt --temporary EMPTY_TEMP_DIRECTORY
Use new report/log paths. The checker enforces a120/121-second CPU bound and64MiB
file bound, rejects network and process launches except bash syntax checks, and
confines writes to the temporary directory and report/log. Production numerical
constructors, checkpoint/runtime and Slurm boundaries remain mocked; tiny generated
CPU likelihood fixtures are real. Actual Linux98-test and CUDA qualification are
separate pending gates. This is not full empirical reproduction or anonymity
clearance. Do not infer any scientific result from fixture success.

The historical summary and receipt companions preserve adverse findings and costs.
They remain separate components until the complete reviewed submission bundle is
assembled and qualified.
