Expanded observed dependency notices: development component

This component preserves the five earlier CPU/publisher notice texts and adds
35 notice/attribution texts from the current shared CUDA Python installation.
The latter cover all 28 distributions reachable from torch and numpy using
installed Requires-Dist metadata on Linux/x86_64/Python3.10.19, with no extras,
plus the installed Python license. All 32 active dependency version constraints
were checked. Conditional and optional edges are retained, not called active.
The 34 distribution notice files match their installed RECORD size/hash entries.
Some notices are outside dist-info; those installation-relative files are included.
Original upstream authorship and notice text are preserved without editing.

METADATA and WHEEL files accompany the observed texts. SOURCES.json preserves
versions, origin scope, the complete declared dependency graph, marker environment,
and file hashes. Its installation path is a labelled placeholder. The current
Torch2.10.0+cu128 and NumPy2.2.6 version strings match the admitted runtime record;
this later file observation does not retroactively bind the notices to frozen
binaries. It is not a loaded-library trace, source/binary equivalence proof or
license clearance. The earlier tokenizers text remains a publisher-source notice,
and the CPU gmpy2 generic license texts do not resolve every native attribution.

No library, wheel, shared object, interpreter binary, model, article, token array
or container is included or installed. The read-only observer did not import Torch
or initialize CUDA. Its small process CPU is reporting overhead, not an empirical
worker debit. No registered job, numerical source, limit or threshold was changed.

Remaining scope includes the actual GPU-node driver/system/compiler/container
installation, non-metadata native dependencies, CPU GMP/MPFR/MPC attributions and
tokenizers Rust dependency/source correspondence. The source project's ownership
and release terms remain an author decision. Retained notices do not settle these.

MANIFEST.json gives size and SHA256 for every other member. Check the archive's
external hash as well; an editable manifest is not an authenticity signature.
This expanded component is staged for the next coherent review bundle. The prior
six-component bundle and its reproduction-guide bindings are unchanged. Do not
replace one of its ZIPs under an old filename. This is preparation, not a final
submission package or a new scientific result.
