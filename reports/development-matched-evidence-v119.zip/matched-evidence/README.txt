E20: complete matched point-token screen

This derivative preserves all sixteen requests from two related GPT-family
checkpoints, both retained endpoints, and four implementation cells. The two
completed cluster audits compare every model, state and trust sidecar against
fresh reconstruction of the same checkpoint. The original terminal binds the
audits, sources, artifacts, allocations and complete accounting. This packaging
step rechecks that bound metadata; it neither reruns models nor reaudits binaries.

The exposed four-record root contains 128 tokens per record. Normalization remains
512 as records are deleted 4->3->2. The point-token route was fixed prospectively
for all cells and oracles; box/Gram policies and approved grids did not change.
Both earlier preparations are reused and retain their full historical costs.
The earlier failed matched attempt and selected-stage diagnostic remain E19.

Every request is one observation, with uncontrolled OS cache. Individual effects
of bundled optimizations are not identified. Stable latency, cross-architecture
generality and predictive quality are not established. Earlier E17 quality is a
different target and is not transferred. The signed contrast convention is
candidate minus modern control: positive values mean slower or larger.

All request rows, nested source accesses, fallbacks and disjoint timing phases
are preserved. Decoder-only timing is unavailable. Preparation is shared; do not
assign its entire cost to one arm or silently call it zero. Scheduler, worker and
controller clocks overlap. Prior failed costs and the unrelated 12,602-second
unknown debit remain separate; no complete historical compute total is claimed.

The component contains descriptive metadata and no model/runtime/corpus binaries,
raw tokens or credentials. Hashes and job IDs can permit identity linkage. Its
integrity check is not a reproduction, anonymity or submission-readiness claim.
