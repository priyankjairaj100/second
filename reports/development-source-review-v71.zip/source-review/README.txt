Current source review component,18 October2026

This component contains577 source/protocol/wrapper copies:575 registered historical
and current numerical files plus two unchanged legacy static-import helpers. It
preserves the failed earlier admission implementation alongside the corrected
quality/frame-audit implementations. The old v69c component remains unchanged.
45 copies adapt only declared account/repository/node/path strings.
All copies reverse exactly to preserved original bytes using a separate private
map. All541 Python ASTs differ only by these declared string replacements.
This is not proof of numerical or operational equivalence after adaptation.

/review/project and /review/runtime are illustrative paths, review_user an account,
reviewcluster.* illustrative nodes and REVIEW_OWNER/REVIEW_REPOSITORY a repository
placeholder. These are not live services. No dependency/model/corpus/environment
binaries, real article tokens, live registrations, ledgers or private mappings are
included. Tiny generated source fixtures are retained. Project release terms are
unassigned; this component does not grant new rights or cover all dependencies.

Do not run old empirical launchers or satisfy original source hashes with these
adapted bytes. A reproduction needs separately admitted paths, actual inputs,
runtime/source bindings, resource budgets, one-use registration and attempts.
Never replay existing job IDs or alter a frozen experiment to run this component.

Local fixture check
Use an existing CPython3.12.7/NumPy2.3.5 environment and an empty temporary directory:
python -I -B qualify_review_source.py PATH_TO_THIS_DIRECTORY --report REPORT.json
--log TESTS.txt --temporary EMPTY_TEMP_DIRECTORY
Use fresh report/log paths. The checker enforces120/121 CPU seconds and64MiB per
file, denies network and process launches except bash syntax checks, and confines
writes to the supplied temporary directory/report/log. Python audit hooks are not
a full OS sandbox. It expects213 generated local tests:22 data,94 failed-campaign
source fixtures and97 corrected-campaign fixtures. Production constructors,
checkpoint/runtime/Slurm boundaries are mocked. Tiny CPU likelihood fixtures run.
The six inherited sequential numerical fixtures are not part of this local subset.

Actual cluster Linux103 checks and generated CUDA24 comparisons are separately
recorded in the research handoff. Their success is not untouched empirical quality.
The active model construction and downstream losses/audits remain unfinished at
this package checkpoint. Clean extraction and these fixtures do not reproduce the
scientific experiment. Full external-input closure, licensing, indirect anonymity,
actual runtime reproduction and final manuscript checks remain incomplete.
