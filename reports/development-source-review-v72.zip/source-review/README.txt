Current source review component,18 October2026

583 source/protocol/wrapper copies:575 historical/current numerical files, six
separately registered accounting-recovery files and two legacy import helpers.
50 copies adapt declared account/repository/node/path strings only.
All copies reverse to preserved originals through a separate private mapping;
all545 Python ASTs differ only by those string replacements. This is not
proof of numerical or operational equivalence after adaptation.

/review/project and /review/runtime are illustrative paths, review_user an account,
reviewcluster.* illustrative nodes and REVIEW_OWNER/REVIEW_REPOSITORY a repository
placeholder. No dependency, model, corpus or runtime binaries, raw article tokens,
live registrations, ledgers or private mappings are included. Tiny generated
fixtures remain. Project release terms are unassigned; no new rights are granted.
Do not run old launchers or use these adapted bytes to satisfy original hashes.
Reproduction needs separately admitted inputs/runtime/paths/budgets and one-use
registration. Never replay existing jobs or alter frozen attempts.

Local fixture check
Use an existing CPython3.12.7/NumPy2.3.5 environment and empty temporary directory:
python -I -B qualify_review_source.py PATH_TO_THIS_DIRECTORY --report REPORT.json
--log TESTS.txt --temporary EMPTY_TEMP_DIRECTORY
Use fresh report/log paths. The checker enforces120/121 CPU seconds and64MiB per
file, denies network/process launches except bash syntax checks, and confines
writes to the supplied outputs. Python audit hooks are not a full OS sandbox.
The same213-test subset covers22 data,94 failed-admission and97 corrected-campaign
fixtures. Production constructors/checkpoint/runtime/Slurm boundaries are mocked;
tiny CPU likelihood fixtures run. Six sequential numerical fixtures are excluded.
The new recovery tests are not part of this portable subset: one requires the
private actual scheduler snapshot, which this anonymous component excludes.
Their earlier local qualification is separate from actual recovery-job success.

V71 actual cluster Linux103 checks, CUDA24 generated comparisons, checkpoint and
sequential audits,1920 GPU losses and24 CPU references are complete. The original
accounting closure failed; separately registered V72 recovery passed without
repeating inference. E17 preserves both outcomes and cost observations. Source
fixtures alone do not reproduce any scientific result. Complete external inputs,
licensing, indirect anonymity and rendered manuscript checks remain unresolved.
All earlier source components remain unchanged under their original names.
