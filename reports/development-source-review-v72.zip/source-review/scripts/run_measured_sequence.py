#!/usr/bin/env python3
"""Run a frozen measured sequence or campaign using local artifacts only."""
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from src.measured_sequence import main
if __name__=='__main__': raise SystemExit(main())
