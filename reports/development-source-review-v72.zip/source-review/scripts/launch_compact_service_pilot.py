"""Freeze sources and run one complete compact transaction within inherited limits."""
import argparse
import hashlib
import json
from pathlib import Path
import os
import shutil
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from src.run_store import canonical_json,atomic_write,digest
from src.experiment_inventory import source_hashes
from src.worker_control import WorkerLimits,run_limited
from src.phase_budget import PhaseBudget


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--id',required=True)
    p.add_argument('--revision',choices=['v13','v15','v17'],default='v13')
    p.add_argument('--grid-axis',choices=['row','dyadic_row'],default='row')
    p.add_argument('--method',choices=['model_only_fresh','repair','indexed_fresh','direct_fresh','quality'],default='direct_fresh')
    p.add_argument('--delete-index',type=int,action='append',choices=[0,1],default=[])
    p.add_argument('--prior-attempt')
    p.add_argument('--initial-model-attempt')
    p.add_argument('--cpu-seconds',type=int,default=900)
    p.add_argument('--solver-backend',choices=['reference','batched','native_ball'],default='reference')
    p.add_argument('--dataset',choices=['wikitext2','c4'],default='wikitext2')
    args=p.parse_args()
    if not args.id.replace('-','').isalnum():raise ValueError('invalid attempt ID')
    if args.method=='quality' and (args.revision!='v13' or args.grid_axis!='row'):
        raise ValueError('legacy quality worker supports only the v13 power-of-two target')
    root=Path(__file__).resolve().parents[1];archive=root/'pilots'/args.revision;attempt=archive/args.id
    if attempt.exists():raise ValueError('attempt exists; failures cannot be overwritten')
    from src.pilot_budget import inherited_allowance
    used,cap=inherited_allowance(root)
    if type(args.cpu_seconds) is not int or not 1 <= args.cpu_seconds <= 900:raise ValueError('invalid worker CPU cap')
    if cap<args.cpu_seconds+2:raise ValueError('insufficient inherited feasibility allowance')
    records=root/f'pilots/v10/{args.dataset}/preflight-records.json'
    original=json.loads(records.read_bytes())['records'];ids=sorted(r['id'] for r in original)
    if len(set(args.delete_index))!=len(args.delete_index):raise ValueError('duplicate deletion index')
    prior=None
    if args.prior_attempt:
        if not args.prior_attempt.replace('-','').isalnum():raise ValueError('invalid prior ID')
        previous=archive/args.prior_attempt
        status=json.loads((previous/'outputs/progress.json').read_bytes())
        receipt=json.loads((previous/'worker/result.json').read_bytes())
        previous_plan_hash=digest((previous/'plan.json').read_bytes())
        if (receipt.get('budget_debit',{}).get('state')!='settled' or receipt.get('outcome',{}).get('status')!='complete'
                or receipt.get('worker_identity',{}).get('plan_sha256')!=previous_plan_hash
                or status.get('plan_sha256')!=previous_plan_hash):
            raise ValueError('prior generation receipt or plan is incomplete or mismatched')
        if status['status']!='complete' or not status.get('complete_state'):raise ValueError('prior state is incomplete')
        state=previous/'outputs/state.bin'
        prior=dict(path=str(state),sha256=status['state_artifact']['sha256'])
        if digest(state.read_bytes())!=prior['sha256']:raise ValueError('prior artifact changed')
    if (args.method in ('repair','indexed_fresh','quality'))!=(prior is not None):raise ValueError('indexed methods require a prior state')
    initial_model=None
    if args.initial_model_attempt:
        if args.method!='model_only_fresh' or args.solver_backend!='native_ball':
            raise ValueError('warm model-only control requires the native backend')
        if not args.initial_model_attempt.replace('-','').isalnum():raise ValueError('invalid model predecessor ID')
        initial=archive/args.initial_model_attempt
        initial_progress=json.loads((initial/'outputs/progress.json').read_bytes())
        initial_receipt=json.loads((initial/'worker/result.json').read_bytes())
        initial_plan_hash=digest((initial/'plan.json').read_bytes())
        if (initial_receipt.get('budget_debit',{}).get('state')!='settled'
                or initial_receipt.get('outcome',{}).get('status')!='complete'
                or initial_receipt.get('worker_identity',{}).get('plan_sha256')!=initial_plan_hash
                or initial_progress.get('plan_sha256')!=initial_plan_hash
                or initial_progress.get('status')!='complete' or not initial_progress.get('complete_model')):
            raise ValueError('initial model predecessor is incomplete or mismatched')
        model_path=initial/'outputs/model.bin'
        initial_model=dict(path=str(model_path),sha256=initial_progress['model_artifact']['sha256'])
        if digest(model_path.read_bytes())!=initial_model['sha256']:raise ValueError('initial model changed')
    complete_program_raw=None
    if args.revision=='v17':
        complete_program_raw=(archive/'complete-program.json').read_bytes()
        complete_program=json.loads(complete_program_raw)
        slots=[row for row in complete_program['sequence'] if row['id']==args.id]
        if len(slots)!=1:raise ValueError('transaction is absent from the frozen v17 program')
        slot=slots[0]
        actual=dict(method=args.method,backend=args.solver_backend,delete=args.delete_index,
            prior=args.prior_attempt,initial_model=args.initial_model_attempt,cpu_seconds=args.cpu_seconds)
        wanted={key:slot.get(key) for key in actual}
        if actual!=wanted:raise ValueError('transaction differs from the frozen v17 program')
    snapshot=attempt/'source';snapshot.mkdir(parents=True)
    for folder in ['src','scripts']:
        (snapshot/folder).mkdir()
        for path in (root/folder).glob('*.py'):shutil.copyfile(path,snapshot/folder/path.name)
    policy=dict(schema='compact-service-diagnostic-policy-v13',attempt_id=args.id,
        inherited_cap_cpu_seconds=10800,prior_charged_cpu_seconds=used,remaining_allowance_cpu_seconds=cap,
        scope='complete factor_identity_v1 transaction; no transport avoidance or primary promotion',
        state_contract='packed exact model plus exact retained factors at current ancestor prefixes',
        mode=args.method,initial_model_used=initial_model is not None,cpu_seconds=args.cpu_seconds,wall_seconds=args.cpu_seconds,solver_backend=args.solver_backend,dataset=args.dataset,revision=args.revision,grid_axis=args.grid_axis,
        numerical_target='fixed output-row four-bit grids, V_cert finite features, original normalization 32',
        os_cache='uncontrolled',other_machine_activity='uncontrolled',scientific_promotion=False)
    if complete_program_raw is not None:
        policy['complete_program_sha256']=digest(complete_program_raw)
        atomic_write(attempt/'complete-program.json',complete_program_raw)
    atomic_write(attempt/'protocol.json',canonical_json(policy));ph=digest(canonical_json(policy))
    cp=root/'tmp/models/distilgpt2';hashes={}
    for name in ['config.json','model.safetensors']:
        with (cp/name).open('rb') as f:hashes[name]=hashlib.file_digest(f,'sha256').hexdigest()
    plan=dict(method=args.method,solver_backend=args.solver_backend,dataset=args.dataset,grid_axis=args.grid_axis,revision=args.revision,checkpoint=str(cp),checkpoint_sha256=hashes,records=str(records),
        records_sha256=digest(records.read_bytes()),deleted_record_ids=[ids[i] for i in args.delete_index],
        prior_state=prior,initial_model=initial_model,complete_program_sha256=policy.get('complete_program_sha256'),output=str(attempt/'outputs'),source_sha256=source_hashes(snapshot),protocol_sha256=ph)
    worker='run_compact_service_pilot.py'
    if args.method=='quality':
        worker='run_v13_quality_pilot.py'
        evaluation=archive/'quality-records.json'
        plan.update(evaluation_records=str(evaluation),evaluation_records_sha256=digest(evaluation.read_bytes()),
            model_order=json.loads(evaluation.read_bytes())['model_order'],
            quantized_model=dict(path=str(previous/'outputs/model.bin'),sha256=status['model_artifact']['sha256']))
    planpath=attempt/'plan.json';atomic_write(planpath,canonical_json(plan))
    from src.runtime_contract import capture_runtime_contract
    atomic_write(attempt/'runtime.json',canonical_json(capture_runtime_contract()))
    limits=WorkerLimits(args.cpu_seconds,args.cpu_seconds,6*2**30,1,(min(os.sched_getaffinity(0)),))
    budget=PhaseBudget(attempt/'phase-cpu-budget',identity={'protocol_sha256':ph,'source_sha256':source_hashes(snapshot)},phase_cpu_seconds={'feasibility':cap})
    result=run_limited([sys.executable,str(snapshot/'scripts'/worker),str(planpath)],attempt/'worker',limits,
        identity={'pilot':'compact-complete-service-v13','plan_sha256':digest(planpath.read_bytes())},cwd=snapshot,
        phase_budget=budget,phase='feasibility')
    print(json.dumps({'outcome':result['outcome'],'budget_debit':result.get('budget_debit'),'resource_usage':result.get('resource_usage')}))


if __name__=='__main__':
    from src.pilot_budget import research_worker_lock
    with research_worker_lock(Path(__file__).resolve().parents[1]):main()
