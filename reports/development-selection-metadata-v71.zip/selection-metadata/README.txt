Selection and exclusion metadata: development review component

This component makes the actual inspected-frame hash inventory, complete before/
after exclusion sets, deterministic selection and saved-data audit receipts
inspectable without redistributing article text, URLs or token sequences. Public
dataset acquisition URLs and hashed article URLs remain in the metadata. It covers
3,801 complete validation-frame articles,2,778 eligible and320 selected. All1,021
short records remain excluded, including their complete-token hashes. The prior
60 quality IDs are preserved. The prior ledger contains7,615 IDs,21,371 content
hashes and29,736 token hashes; the successor has11,416,32,331 and44,538 respectively.

Eleven JSON copies preserve every typed field under declared account/host/path
string replacements. SOURCES.json distinguishes original commitments from the
new copied-body commitments. A private reversible mapping is excluded. This does
not make these copied registrations/receipts the exact executed bytes. Hashes and
source similarity may still link a public project; full indirect anonymity is not
established. No original experiment source, saved artifact, target or limit changed.

Offline check
Extract into a new directory and run an existing CPython3.10+ interpreter:
python3 -I -B verify_selection.py
No dependencies are installed. The script checks its component inventory/hashes,
recomputes every eligibility reason from saved hashes in original frame order,
the exact full-frame successor exclusion union, the fixed sampling order and the
selected metadata. Its five core functions match the separately checked reporting
implementation. It refuses missing, altered or extra files. Audit hooks deny
writes, subprocesses and network; they are not a complete operating-system sandbox.
Check the external ZIP hash as well; editable manifests are not signatures.

Scope of evidence
This is a metadata reconciliation. It does not read or download the compressed
source prefix, retokenize text, verify actual token words, reconstruct models or
compute likelihoods. The completed original data and full-frame audits remain the
source for corpus-to-hash correspondence. Those audits shared the preparation
tokenizer implementation. No corpus-uniform sampling, semantic deduplication,
untouched-quality outcome or model superiority is established by this checker.

The registered quality run remains separate. Its complete CPU/CUDA parity, loss,
model and cost audits are required before quality claims. Historical token bodies,
model/state binaries, the full historical input graph and external runtime are not
included here. Original one-use launchers must never be replayed. Any new numerical
reproduction needs its own input/runtime admission and prospective registration.

This is a staged component for the next coherent review bundle. Existing six-
component archive/guide bindings are unchanged. The expanded dependency notices
are staged separately. No final submission, complete rights assessment or new
project license is supplied by this preparation.
