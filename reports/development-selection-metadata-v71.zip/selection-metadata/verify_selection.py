"""Read-only saved-hash/selection check; no dataset or numerical execution."""
from pathlib import Path
import hashlib,json,re,sys
SHA = re.compile('[0-9a-f]{64}')

def canonical(x):
    return json.dumps(x, sort_keys=True, separators=(',', ':'), ensure_ascii=True, allow_nan=False).encode('ascii')

def info(raw):
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())

def pairs(items):
    result = {}
    for key, value in items:
        assert key not in result, 'Duplicate JSON key'
        result[key] = value
    return result

def parse(raw):
    return json.loads(raw, object_pairs_hook=pairs, parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))

def reconcile_selection(x):
    before, after = x['before'], x['after']
    selection, inventory = x['selection'], x['inventory']
    full = x['frame_audit']['result']['complete_token_hashes']
    for excluded in (before, after):
        assert set(excluded) == {'ids', 'content', 'chunks'}
        assert all(type(values) is list and all(type(v) is str for v in values)
                   and values == sorted(set(values)) for values in excluded.values())
        assert all(SHA.fullmatch(v) for key in ('content', 'chunks') for v in excluded[key])
    prior = {k: set(v) for k, v in before.items()}
    seen = {k: set() for k in before}
    expected = {k: set(v) for k, v in before.items()}
    rows = inventory['candidates']
    assert len(rows) == len(full) == selection['candidate_articles'] == 3801
    assert inventory['frame'] == selection['frame']
    assert selection['frame']['complete_records'] == 3801
    assert selection['frame']['whole_gzip_trailer_verified'] is False
    assert [r['line_index'] for r in rows] == list(range(3801))
    assert [f['id'] for f in full] == [r['id'] for r in rows]
    content_keys = ('body_sha256', 'normalized_text_sha256', 'url_sha256')

    def reasons(row, protected):
        result = []
        if row['available_tokens'] < 128:
            result.append('short_record')
        if row['id'] in protected['ids']:
            result.append('id_overlap')
        if any(row[k] in protected['content'] for k in content_keys):
            result.append('content_or_url_overlap')
        if any(v in protected['chunks'] for v in row['token_prefixes'].values()):
            result.append('token_prefix_overlap')
        return result

    short = 0
    for row, token in zip(rows, full):
        assert set(row) == {'id', 'line_index', 'available_tokens', *content_keys,
                            'token_prefixes', 'eligible', 'exclusion_reasons'}
        assert row['id'] == 'c4:en:validation:shard1:line' + str(row['line_index'])
        assert type(row['available_tokens']) is int and row['available_tokens'] >= 0
        assert all(type(row[k]) is str and SHA.fullmatch(row[k]) for k in content_keys)
        count = min(128, row['available_tokens'])
        assert set(token) == {'id', 'token_count', 'tokens_sha256'}
        assert type(token['token_count']) is int and token['token_count'] == count
        assert type(token['tokens_sha256']) is str and SHA.fullmatch(token['tokens_sha256'])
        assert set(row['token_prefixes']) == {str(n) for n in (16, 32, 64, 128) if count >= n}
        assert all(type(v) is str and SHA.fullmatch(v) for v in row['token_prefixes'].values())
        if str(count) in row['token_prefixes']:
            assert token['tokens_sha256'] == row['token_prefixes'][str(count)]
        if count == 0:
            assert token['tokens_sha256'] == info(canonical([]))['sha256']
        why = reasons(row, prior)
        if not why:
            why = ['within_frame_' + reason for reason in reasons(row, seen)]
        assert type(row['eligible']) is bool and row['eligible'] == (not why)
        assert row['exclusion_reasons'] == why
        for destination in (seen, expected):
            destination['ids'].add(row['id'])
            destination['content'].update(row[k] for k in content_keys)
            destination['chunks'].update(row['token_prefixes'].values())
            if count:
                destination['chunks'].add(token['tokens_sha256'])
        short += count < 128
    assert after == {k: sorted(v) for k, v in expected.items()}, 'Exact full-frame union differs'
    assert short == x['frame_audit']['result']['short_records'] == 1021
    seed = selection['policy']['order_seed']
    assert seed == 'second-v68-untouched-quality-frame-before-loss:'
    eligible = sorted((r['id'] for r in rows if r['eligible']),
                      key=lambda rid: (hashlib.sha256((seed + rid).encode()).hexdigest(), rid))
    assert eligible == inventory['eligible_ids_in_sampling_order']
    assert len(eligible) == selection['eligible_articles'] == 2778
    selected = eligible[:320]
    assert selection['sampling_order_ids'] == selected
    assert selection['selected_articles'] == selection['requested_articles'] == 320
    byid = {r['id']: r for r in rows}
    expected_selected = [dict(
        id=rid, line_index=byid[rid]['line_index'], available_tokens=byid[rid]['available_tokens'],
        **{k: byid[rid][k] for k in content_keys}, token_offset=0, split='validation') for rid in selected]
    assert selection['selected_metadata'] == expected_selected
    history = x['historical-quality-exclusions']['excluded_from_future_confirmation_ids']
    assert len(history) == len(set(history)) == 60 and set(history) <= prior['ids']
    return dict(frame_records=3801,eligible_records=2778,selected_records=320,short_records=1021,
                historical_quality_ids_preserved=60,
                before_counts={k: len(v) for k, v in before.items()},
                after_counts={k: len(v) for k, v in after.items()},
                all_eligibility_reasons_recomputed=True,exact_inspected_frame_union=True,
                fixed_sampling_order_recomputed=True,selected_metadata_matches=True)

def main():
    root = Path(__file__).resolve().parent
    def readonly(event,args):
        if event == 'open':
            path,mode,flags = args
            import os
            if isinstance(path,int):
                raise PermissionError('No descriptor opens')
            path = Path(path).resolve()
            if not path.is_relative_to(root) or (mode and any(c in mode for c in 'wax+')) or flags & (os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND):
                raise PermissionError('Read only within this extracted component')
        elif event.startswith(('socket.','subprocess.')) or event in ('os.system','os.exec','os.posix_spawn','os.spawn','os.remove','os.rename','os.mkdir','os.rmdir','os.symlink','os.link','os.chmod'):
            raise PermissionError('No writes, processes or network')
    sys.addaudithook(readonly)
    entries = list(root.rglob('*'))
    assert all(not p.is_symlink() for p in entries)
    paths = {str(p.relative_to(root)):p for p in entries if p.is_file()}
    assert len(paths) <= 20 and sum(p.stat().st_size for p in paths.values()) <= 16*2**20
    manifest = parse((root/'MANIFEST.json').read_bytes())
    assert set(paths) == set(manifest)|{'MANIFEST.json'}
    for name,expected in manifest.items():
        assert info(paths[name].read_bytes()) == expected
    sources = parse((root/'SOURCES.json').read_bytes())
    x = {}
    for name,commitment in sources['derivative_metadata'].items():
        raw = (root/name).read_bytes()
        assert info(raw) == commitment
        x[name.removesuffix('.json')] = parse(raw)
    result = reconcile_selection(x)
    result.update(status='saved_metadata_decisions_verified',raw_corpus_or_tokens_read=False,
        corpus_to_hash_correspondence_verified=False,likelihood_result=False,
        original_registration_replayed=False,full_historical_input_closure=False)
    print(json.dumps(result,sort_keys=True))

if __name__ == '__main__':
    main()
