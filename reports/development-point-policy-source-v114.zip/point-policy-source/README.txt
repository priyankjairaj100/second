Point-policy source inspection supplement,27 October2026

This adds96 source/protocol/test copies to the unchanged1226 earlier copies.
Together they cover all1322 source entries in the exact qualified V112 package.
Seventeen execution-specific receipts are omitted and enumerated. Their original
versions and the derivation map remain in the public research repository.

The original V112 package passed318 pinned Linux software checks and its matched
numerical chain was released once. At this package checkpoint that chain was
running; no completed full-model transfer or general speedup result is supplied.
The new policy chooses the existing token route for point solves in all cells
and fresh oracles. The binary audit reader repair preserves the original caps.
All older failed sources and existing-token diagnostic sources remain included.

Declared path/account/node/repository strings are reversibly adapted. Python ASTs
are checked to differ only in those strings; adapted execution is not qualified.
These copies are for inspection. Do not run historical launchers, retry consumed
jobs, or pass adapted bytes to original hash gates. No model/corpus/token-body/
runtime binaries or credentials are added. Small generated fixtures remain.
No project license is newly assigned. Public originals can reveal identity;
anonymity is not established. Offline source coverage is not empirical replication.
