Observed dependency notices: development companion

Five unchanged notice texts are included: NumPy LICENSE, gmpy2 COPYING and
COPYING.LESSER, zstandard LICENSE, and the tokenizers publisher LICENSE.
SOURCES.json distinguishes installed distribution notices from publisher source.
No package, shared library, model, corpus or container is included or installed.

The four installed CPU texts were observed in versioned distribution directories.
The zstandard text matches an original frozen runtime commitment. The other
notice bytes were observed later and do not retroactively extend runtime pins.
NumPy's file contains its supplied bundled-library notices. Generic GPL/LGPL
texts do not by themselves identify every GMP/MPFR/MPC component notice.

Tokenizers' installed distribution directory had no notice. The supplied text
comes instead from its publisher's immutable source commit, whose Cargo metadata
declares version0.23.2 and Apache-2.0. Its Git blob commitment was verified. This
does not prove which Rust dependencies/features are in the installed wheel or
establish installed-wheel/source equivalence. Rust transitive notices remain open.

Python/system/compiler/container and the future GPU environment's complete
notices are not supplied. These are external installations, not vendored binaries.
No license is assigned to the research project's own source by this companion.
The authors' release terms and final artifact review remain separate.

MANIFEST.json lists the size and SHA256 of every other member. Verify this ZIP's
externally supplied hash and then the manifest before relying on these copies.
This is a supplement to the four existing review components, not a replacement.
Their bytes and the manuscript are unchanged. This archive is not an experiment
result, complete rights assessment or submission-ready package.
